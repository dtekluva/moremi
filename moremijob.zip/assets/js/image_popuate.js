

  /*-------------------------------------------------------------------------------
    PRE LOADER
  -------------------------------------------------------------------------------*/

  $(window).load(function(){
    $('.preloader').fadeOut(1000); // set duration in brackets    
  });


  /*-------------------------------------------------------------------------------
    jQuery Parallax
  -------------------------------------------------------------------------------*/
  const image_entries = document.getElementsByClassName('image');
  const image_array     = ["kitchen.jpg","kitchen3.jpg","kitchen2.jpg" ];
  console.log(image_entries);
  var index = 0;

  // function populate_images(){
  //   image_entries.forEach((element, index) => {
  //     var image_html = '<img src="assets/images/'+ image_array[index] + '" alt="">'
  //     element[0].innerHTML = image_html;
  //   });
  // };
  // populate_images();

  for (const key in image_entries) {
    console.log(key)
    if (image_entries.hasOwnProperty(key)) {
      const element = image_entries[key];
      var image_html = '<img src="assets/images/'+ image_array[index] + '" alt="">';
      element.innerHTML = image_html;
    }
    index += 1;
    if (index === image_array.length){
      break;
    }
  }
   


  /* Back top
  -----------------------------------------------*/
  
  

